import csv
from flask import *
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def calculate():
    if request.method == 'POST':
        num1 = request.form['num1']
        num2 = request.form['num2']
        operator = request.form['operator']
        result = None

        if operator == 'add':
            result = float(num1) + float(num2)
        elif operator == 'subtract':
            result = float(num1) - float(num2)
        elif operator == 'multiply':
            result = float(num1) * float(num2)
        elif operator == 'divide':
            if num2 == '0':
                result = 'Cannot divide by zero'
            else:
                result = float(num1) / float(num2)

        with open('calculator.csv', mode='a') as calculate_file:
            calculate_writer = csv.writer(calculate_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
            calculate_writer.writerow([num1, operator, num2,result])
        return render_template('calculate.html', result=result)

    return render_template('calculate.html')

if __name__ == '__main__':
    app.run(debug=True,port=2202,host='0.0.0.0')

